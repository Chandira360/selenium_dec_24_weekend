package testcases;

import org.testng.annotations.Test;

import base.PSM;
import pages.LoginPage;

public class TC_002_Leads extends PSM{

	@Test
	public void runLeads() {
		new LoginPage(driver)
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfa()
		.clickLeadsTab();
	}
	
}
