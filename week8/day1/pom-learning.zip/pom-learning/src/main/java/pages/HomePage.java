package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.PSM;

public class HomePage extends PSM{
	
	public HomePage(RemoteWebDriver driver) {
		this.driver = driver;
	}

	public void clickLeadsTab() {
		driver.findElement(By.linkText("Leads")).click();
	}
	
	public void clickAccountsTab() {
		
	}

}
