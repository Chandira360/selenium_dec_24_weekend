package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.PSM;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends PSM{
	
	
	
	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String uname) {
		System.out.println("driver instance in enter username  "+getDriver());
		getDriver().findElement(By.id("username")).sendKeys(uname);
		// use return type for page navigation
//		LoginPage lp = new LoginPage();
//		return lp;
//		return new LoginPage();
		return this;
	}
	
	@Given("Enter the password as {string}")
	public LoginPage enterPassword(String pwd) {
		getDriver().findElement(By.id("password")).sendKeys(pwd);
		return this;
	}
	
	@When("Click on the login button")
	public WelcomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}
	
}
