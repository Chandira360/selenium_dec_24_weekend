package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.PSM;

public class HomePage extends PSM{
	
	
	public void clickLeadsTab() {
		getDriver().findElement(By.linkText("Leads")).click();
	}
	
	public void clickAccountsTab() {
		
	}

}
