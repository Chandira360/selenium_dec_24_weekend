package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class PSM extends AbstractTestNGCucumberTests {

//public  RemoteWebDriver driver; // static keyword helps to make the property as single memory
	private static ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();
	@BeforeMethod
	public void preCondition() {
//		driver = new ChromeDriver(); // if declared as local throw nullPointerException
		setDriver(new ChromeDriver());
//		driver = new EdgeDriver();
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		getDriver().get("http://leaftaps.com/opentaps/");
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().quit();
		}
	
	public void setDriver(RemoteWebDriver driver) {
		rd.set(driver);
	}
	
	public RemoteWebDriver getDriver() {
		return rd.get();
	}
	
}
