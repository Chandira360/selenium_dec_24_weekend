package testcases;

import org.testng.annotations.Test;

import base.PSM;
import pages.LoginPage;

public class TC_002_Leads extends PSM{

	@Test
	public void runLeads() {
		new LoginPage()
		.enterUsername("demosalesmanager")
		.enterPassword("crmsfa")
		.clickLoginButton()
		.clickCrmsfa()
		.clickLeadsTab();
	}
	
}
