package testcases;

import org.testng.annotations.Test;

import base.PSM;
import pages.LoginPage;

public class TC_001_Login extends PSM{

	@Test
	public void runLogin() {
//		LoginPage lp = new LoginPage();
//		lp.enterUsername();
//		lp.enterPassword();
//		lp.clickLoginButton();
		System.out.println("driver instance in Test "+getDriver());
//		lp.enterUsername()
//		.enterPassword()
//		.clickLoginButton()
//		.clickLogoutButton();
//		
//		
		new LoginPage()
		.enterUsername("demosalesmanager")
		.enterPassword("crmsfa")
		.clickLoginButton();
		
	}
	
}
