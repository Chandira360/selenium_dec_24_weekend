package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class PSM extends AbstractTestNGCucumberTests {

//public  RemoteWebDriver driver; // static keyword helps to make the property as single memory
	private static ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();

	static ExtentReports report;
	public static String testcaseName, testcaseDesc, authorName, categoryName;
	public static ExtentTest node;
	File snapFolder;
	@BeforeMethod
	public void preCondition() {
//		driver = new ChromeDriver(); // if declared as local throw nullPointerException
		setDriver(new ChromeDriver());
//		driver = new EdgeDriver();
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		getDriver().get("http://leaftaps.com/opentaps/");
	}

	@AfterMethod
	public void postCondition() {
		getDriver().quit();
	}

	public void setDriver(RemoteWebDriver driver) {
		rd.set(driver);
	}

	public RemoteWebDriver getDriver() {
		return rd.get();
	}

	// ------------------------Report configuration-----------------------

	@BeforeSuite
	public void startReport() throws IOException {
		LocalDateTime curentDateAndTime = LocalDateTime.now();
		DateTimeFormatter ofPattern = DateTimeFormatter.ofPattern("dd-MM-yyyy_HH-mm-ss");
		String format = ofPattern.format(curentDateAndTime);
		System.out.println(format);

		File reportFolder = new File(System.getProperty("user.dir") + "/report/" + format);
		boolean mkdir = reportFolder.mkdirs();
		snapFolder = new File(reportFolder+"/snaps");
		System.out.println(mkdir);
		reportFolder = new File(System.getProperty("user.dir") + "/report/" + format + "/result.html");
		// Set the path for report
		ExtentHtmlReporter reporter = new ExtentHtmlReporter(reportFolder);
		reporter.setAppendExisting(true);// maintain history
		// Create Report
		report = new ExtentReports();
		// attach the report to the report path
		report.attachReporter(reporter);

	}

	@BeforeClass
	public void startTestCase() {
		ExtentTest test = report.createTest(testcaseName, testcaseDesc);
		node = test.createNode(testcaseName);
		node.assignAuthor(authorName);
		node.assignCategory(categoryName);

	}

	@AfterSuite
	public void endReport() {
		// close the report
		report.flush();
	}
	
	public int takeSnap() throws IOException {
		int randomNumber = (int)(Math.random()*999999);
		File screenShot = getDriver().getScreenshotAs(OutputType.FILE);
		File screenShotLocation = new File(snapFolder+"/img"+randomNumber+".png");
		System.out.println(screenShotLocation.getName());
		FileUtils.copyFile(screenShot, screenShotLocation);
		return randomNumber;
	}
	
	public void reportStep(String status, String descMsg) {
		try {
			if(status.equalsIgnoreCase("pass")) {
				node.pass(descMsg, MediaEntityBuilder.createScreenCaptureFromPath("./img"+takeSnap()+".png").build());
			}else if(status.equalsIgnoreCase("fail")) {
				node.fail(descMsg,  MediaEntityBuilder.createScreenCaptureFromPath("./img"+takeSnap()+".png").build());
			}
		} catch (IOException e) {
			
		}
	}
	
}
