package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.PSM;
import pages.LoginPage;

public class TC_002_Leads extends PSM{

	@Test
	public void runLeads() {
		new LoginPage()
		.enterUsername("demosalesmanager")
		.enterPassword("crmsfa")
		.clickLoginButton()
		.clickCrmsfa()
		.clickLeadsTab();
	}
	
	@BeforeTest
	public void setDetails() {
		testcaseName ="Leads module TC_002";
		testcaseDesc ="Leads functionality";
		authorName = "Gokul";
		categoryName = "Smoke";
	}
	
}
