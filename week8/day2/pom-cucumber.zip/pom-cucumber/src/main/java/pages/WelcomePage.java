package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.PSM;

public class WelcomePage extends PSM{
	
	

	public LoginPage clickLogoutButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}
	
	public HomePage clickCrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new HomePage();
	}
	
	
}
