package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.PSM;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends PSM{
	
	
	
	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String uname) {
		System.out.println("driver instance in enter username  "+getDriver());
		try {
			getDriver().findElement(By.id("username")).sendKeys(uname);
//			node.pass("username entered successful as "+uname);
			reportStep("pass", "username entered successfully as "+uname);
		} catch (Exception e) {
//			node.fail("failed to enter username as "+uname+" and the exception is "+e);
			reportStep("fail", "failed to enter the username and the exception is "+e);
		}
		// use return type for page navigation
//		LoginPage lp = new LoginPage();
//		return lp;
//		return new LoginPage();
		return this;
	}
	
	@Given("Enter the password as {string}")
	public LoginPage enterPassword(String pwd) {
		try {
			getDriver().findElement(By.id("password")).sendKeys(pwd);
			reportStep("pass", "password entered successful as "+pwd);
		} catch (Exception e) {
			reportStep("fail", "failed to enter the password and the exception is "+e);
		}
		return this;
	}
	
	@When("Click on the login button")
	public WelcomePage clickLoginButton() {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("pass", "Login button clicked successful");
		} catch (Exception e) {
			reportStep("fail", "failed to click on the login button and the exception is "+e);
		}
		return new WelcomePage();
	}
	
}
