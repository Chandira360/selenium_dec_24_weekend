package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import base.PSM;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"src/main/resources/features"}, glue= {"pages"}, publish = true, monochrome = true)
public class CucumberRunner extends PSM{

//	@DataProvider(parallel = true)
//	public Object[][] scenarios() {
//		return super.scenarios();
//	}
	
	@BeforeTest
	public void setDetails() {
		testcaseName ="Login TC_001";
		testcaseDesc ="Login testcase with valid test data";
		authorName = "Gokul";
		categoryName = "Regression";
	}

	
}
