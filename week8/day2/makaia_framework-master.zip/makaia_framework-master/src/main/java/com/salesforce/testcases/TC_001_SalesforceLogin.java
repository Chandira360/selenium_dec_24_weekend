package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.LoginPage;

public class TC_001_SalesforceLogin extends ProjectSpecificMethods{

	@BeforeTest
	public void setValues() {
		testcaseName = "Verify Salesforce Login";
		testDescription ="Verify the salesforce Login functionality with positive data";
		authors="Gokul";
		category ="Smoke";
		excelFileName="Login";
	}
	
	@Test(dataProvider = "fetchData")
	public void runSalesforceLogin(String uname, String pwd) {
		
		new LoginPage()
		.enterUsername(uname)
		.enterPassword(pwd)
		.clickLoginButton();
		
	}
}
