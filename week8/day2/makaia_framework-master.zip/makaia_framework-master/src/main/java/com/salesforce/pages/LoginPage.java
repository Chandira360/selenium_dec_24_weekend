package com.salesforce.pages;

import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	
	public LoginPage enterUsername(String uname) {
		
		return this;
	}
	
	public LoginPage enterPassword(String pwd) {
		
		return this;
	}
	
	public WelcomePage clickLoginButton() {
	
		return new WelcomePage();
	}
	
	
}
